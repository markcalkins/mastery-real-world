<template>
  <div class="about">
    <h1>A site for events to better the community.</h1>
  </div>
</template>
